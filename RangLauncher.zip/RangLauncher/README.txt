Rang Launcher - GitHub par APK banane ke steps
1. github.com par naya repository banao.
2. Is zip ke andar ke saare files/folders repository me upload karo (.github folder bhi).
3. Actions tab -> "Build APK" chalne do (3-5 min).
4. Run kholo -> Artifacts -> RangLauncher-APK download karo, unzip karke APK install karo.
5. Home dabao -> "Rang Launcher" chuno -> Always. Settings ke liye clock ko long-press ya upar gear dabao.
