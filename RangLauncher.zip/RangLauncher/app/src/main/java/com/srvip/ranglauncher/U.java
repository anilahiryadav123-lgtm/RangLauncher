package com.srvip.ranglauncher;
import android.content.*;
import android.graphics.drawable.*;
import android.util.TypedValue;
public class U {
    static final String[] THEME_NAMES = {"Aurora","Sunset","Ocean","Jungle","Fire","Midnight","Neon","Candy"};
    static final int[][] GRADS = {
        {0xFF1A0B5E,0xFF6A11CB,0xFF2575FC},{0xFFFF512F,0xFFDD2476,0xFF8E2DE2},
        {0xFF00C9FF,0xFF0072FF,0xFF7F00FF},{0xFF0B486B,0xFF11998E,0xFF38EF7D},
        {0xFFF7971E,0xFFFF4E50,0xFFC33764},{0xFF0F2027,0xFF203A43,0xFF2C5364},
        {0xFFFC466B,0xFF3F5EFB,0xFF00B09B},{0xFF2B1055,0xFF7597DE,0xFFFF9A9E}};
    static final int[][] PAL = {
        {0xFFFF5F6D,0xFFFFC371},{0xFF36D1DC,0xFF5B86E5},{0xFF11998E,0xFF38EF7D},{0xFFFC466B,0xFF3F5EFB},
        {0xFFF7971E,0xFFFFD200},{0xFF8E2DE2,0xFF4A00E0},{0xFFFF0099,0xFFFF6A00},{0xFF00C6FF,0xFF0072FF},
        {0xFFEB3349,0xFFF45C43},{0xFF56AB2F,0xFFA8E063},{0xFFDA22FF,0xFF9733EE},{0xFF1FA2FF,0xFF12D8FA}};
    static int dp(Context c, float v){ return (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics()); }
    static SharedPreferences sp(Context c){ return c.getSharedPreferences("rang", 0); }
    static GradientDrawable bg(Context c){
        return new GradientDrawable(GradientDrawable.Orientation.TL_BR, GRADS[sp(c).getInt("theme",0)]);
    }
    static GradientDrawable round(int color, float r){
        GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(r); return g;
    }
    static GradientDrawable grad(int[] p, float r){
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, p); g.setCornerRadius(r); return g;
    }
    static Drawable icon(Context c, Drawable d, String key, int sizeDp){
        int s = dp(c, sizeDp);
        int[] p = PAL[Math.abs(key.hashCode()) % PAL.length];
        int shape = sp(c).getInt("shape", 1);
        float r = shape==0 ? s/2f : shape==1 ? s*0.32f : s*0.1f;
        return new LayerDrawable(new Drawable[]{ grad(p, r), new InsetDrawable(d, (int)(s*0.14f)) });
    }
}
