package com.srvip.ranglauncher;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.util.*;

public class HomeActivity extends Activity {
    static class Item { String label, pkg; Drawable icon; }
    PackageManager pm;
    List<Item> all = new ArrayList<>(), shown = new ArrayList<>();
    GridView grid; EditText search; LinearLayout dock, col; FrameLayout root; BaseAdapter ad;
    int builtTheme = -1, builtCols = -1;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        pm = getPackageManager();
        getWindow().getDecorView().setSystemUiVisibility(1792);
        build();
    }

    int isz() { int c = U.sp(this).getInt("cols", 4); return c == 4 ? 58 : c == 5 ? 52 : 46; }

    void build() {
        root = new FrameLayout(this);
        root.setBackground(U.bg(this));
        col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        final int s = U.dp(this, 16);
        col.setPadding(s, U.dp(this, 40), s, U.dp(this, 24));
        root.setOnApplyWindowInsetsListener((v, i) -> {
            col.setPadding(s, i.getSystemWindowInsetTop() + U.dp(this, 8), s, i.getSystemWindowInsetBottom() + U.dp(this, 8));
            return i;
        });
        TextClock time = new TextClock(this);
        time.setFormat12Hour("hh:mm"); time.setFormat24Hour("HH:mm");
        time.setTextSize(64); time.setTextColor(Color.WHITE);
        time.setTypeface(Typeface.create("sans-serif-thin", Typeface.NORMAL));
        time.setGravity(Gravity.CENTER);
        time.setOnLongClickListener(v -> { startActivity(new Intent(this, SettingsActivity.class)); return true; });
        TextClock date = new TextClock(this);
        date.setFormat12Hour("EEEE, d MMMM"); date.setFormat24Hour("EEEE, d MMMM");
        date.setTextSize(16); date.setTextColor(0xFFFFE066); date.setGravity(Gravity.CENTER);
        col.addView(time); col.addView(date);

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.topMargin = U.dp(this, 14); rp.bottomMargin = U.dp(this, 8);
        search = new EditText(this);
        search.setHint("Search apps…"); search.setHintTextColor(0xAAFFFFFF); search.setTextColor(Color.WHITE);
        search.setSingleLine(true); search.setBackground(U.round(0x33FFFFFF, U.dp(this, 24)));
        search.setPadding(U.dp(this, 18), U.dp(this, 10), U.dp(this, 18), U.dp(this, 10));
        row.addView(search, new LinearLayout.LayoutParams(0, -2, 1));
        TextView gear = new TextView(this);
        gear.setText("⚙"); gear.setTextSize(24); gear.setTextColor(Color.WHITE); gear.setGravity(Gravity.CENTER);
        gear.setBackground(U.grad(U.PAL[6], U.dp(this, 24)));
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(U.dp(this, 48), U.dp(this, 48));
        gp.leftMargin = U.dp(this, 10);
        gear.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        row.addView(gear, gp);
        col.addView(row, rp);
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence a, int b, int c, int d) {}
            public void onTextChanged(CharSequence a, int b, int c, int d) { filter(); }
            public void afterTextChanged(Editable e) {}
        });
        search.setOnEditorActionListener((v, a, e) -> { if (!shown.isEmpty()) launch(shown.get(0)); return true; });

        grid = new GridView(this);
        grid.setNumColumns(U.sp(this).getInt("cols", 4));
        grid.setVerticalSpacing(U.dp(this, 14));
        grid.setSelector(new ColorDrawable(Color.TRANSPARENT));
        grid.setVerticalScrollBarEnabled(false);
        ad = new BaseAdapter() {
            public int getCount() { return shown.size(); }
            public Object getItem(int i) { return shown.get(i); }
            public long getItemId(int i) { return i; }
            public View getView(int i, View cv, ViewGroup p) {
                LinearLayout l; ImageView iv; TextView tv;
                if (cv == null) {
                    l = new LinearLayout(HomeActivity.this); l.setOrientation(LinearLayout.VERTICAL); l.setGravity(Gravity.CENTER_HORIZONTAL);
                    iv = new ImageView(HomeActivity.this); l.addView(iv);
                    tv = new TextView(HomeActivity.this); tv.setTextColor(Color.WHITE); tv.setTextSize(11); tv.setSingleLine(true);
                    tv.setEllipsize(android.text.TextUtils.TruncateAt.END); tv.setGravity(Gravity.CENTER);
                    tv.setShadowLayer(4, 0, 2, 0xAA000000); l.addView(tv);
                } else l = (LinearLayout) cv;
                iv = (ImageView) l.getChildAt(0); tv = (TextView) l.getChildAt(1);
                int sz = isz();
                iv.setLayoutParams(new LinearLayout.LayoutParams(U.dp(HomeActivity.this, sz), U.dp(HomeActivity.this, sz)));
                Item it = shown.get(i);
                iv.setImageDrawable(U.icon(HomeActivity.this, it.icon, it.pkg, sz));
                tv.setText(it.label);
                tv.setVisibility(U.sp(HomeActivity.this).getBoolean("labels", true) ? View.VISIBLE : View.GONE);
                return l;
            }
        };
        grid.setAdapter(ad);
        grid.setOnItemClickListener((p, v, i, id) -> launch(shown.get(i)));
        grid.setOnItemLongClickListener((p, v, i, id) -> { menu(shown.get(i)); return true; });
        col.addView(grid, new LinearLayout.LayoutParams(-1, 0, 1));

        dock = new LinearLayout(this);
        dock.setGravity(Gravity.CENTER); dock.setBackground(U.round(0x33FFFFFF, U.dp(this, 30)));
        dock.setPadding(0, U.dp(this, 10), 0, U.dp(this, 10));
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1, -2);
        dp.topMargin = U.dp(this, 8);
        col.addView(dock, dp);
        root.addView(col);
        setContentView(root);
    }

    @Override protected void onResume() {
        super.onResume();
        int t = U.sp(this).getInt("theme", 0), c = U.sp(this).getInt("cols", 4);
        if (builtTheme != -1 && (t != builtTheme || c != builtCols)) build();
        builtTheme = t; builtCols = c;
        load(); buildDock();
    }
    @Override protected void onNewIntent(Intent i) { super.onNewIntent(i); search.setText(""); grid.smoothScrollToPosition(0); }
    @Override public void onBackPressed() {}

    void load() {
        all.clear();
        Intent in = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        for (ResolveInfo r : pm.queryIntentActivities(in, 0)) {
            Item it = new Item();
            it.label = String.valueOf(r.loadLabel(pm)); it.pkg = r.activityInfo.packageName; it.icon = r.loadIcon(pm);
            all.add(it);
        }
        Collections.sort(all, (a, b) -> a.label.compareToIgnoreCase(b.label));
        filter();
    }
    void filter() {
        String q = search.getText().toString().toLowerCase().trim();
        shown.clear();
        for (Item it : all) if (q.isEmpty() || it.label.toLowerCase().contains(q)) shown.add(it);
        ad.notifyDataSetChanged();
    }
    void launch(Item it) {
        Intent i = pm.getLaunchIntentForPackage(it.pkg);
        if (i != null) startActivity(i);
    }
    void menu(Item it) {
        new AlertDialog.Builder(this).setTitle(it.label).setItems(new String[]{"App info", "Uninstall"}, (d, w) -> {
            if (w == 0) startActivity(new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + it.pkg)));
            else startActivity(new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + it.pkg)));
        }).show();
    }
    void buildDock() {
        dock.removeAllViews();
        Intent[] ins = {
            new Intent(Intent.ACTION_DIAL),
            new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING),
            new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.google.com")).addCategory(Intent.CATEGORY_BROWSABLE),
            new Intent(MediaStore.ACTION_IMAGE_CAPTURE)};
        for (final Intent in : ins) {
            ResolveInfo r = pm.resolveActivity(in, PackageManager.MATCH_DEFAULT_ONLY);
            if (r == null || r.activityInfo == null || "android".equals(r.activityInfo.packageName)) continue;
            ImageView iv = new ImageView(this);
            iv.setImageDrawable(U.icon(this, r.loadIcon(pm), String.valueOf(r.loadLabel(pm)), 56));
            iv.setOnClickListener(v -> { try { startActivity(in); } catch (Exception e) {} });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, U.dp(this, 56), 1);
            lp.leftMargin = lp.rightMargin = U.dp(this, 8);
            dock.addView(iv, lp);
        }
    }
}
