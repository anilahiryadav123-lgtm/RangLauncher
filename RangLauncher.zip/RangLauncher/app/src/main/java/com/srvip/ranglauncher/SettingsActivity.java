package com.srvip.ranglauncher;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class SettingsActivity extends Activity {
    LinearLayout col;
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(1792);
        FrameLayout root = new FrameLayout(this);
        root.setBackground(U.bg(this));
        ScrollView sv = new ScrollView(this);
        col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL);
        final int p = U.dp(this, 16);
        col.setPadding(p, U.dp(this, 48), p, U.dp(this, 40));
        root.setOnApplyWindowInsetsListener((v, i) -> {
            col.setPadding(p, i.getSystemWindowInsetTop() + U.dp(this, 12), p, i.getSystemWindowInsetBottom() + U.dp(this, 24));
            return i;
        });
        sv.addView(col); root.addView(sv); setContentView(root);

        title("🎨 Rang Launcher Settings", 24);
        title("Theme", 16);
        HorizontalScrollView hs = new HorizontalScrollView(this); hs.setHorizontalScrollBarEnabled(false);
        LinearLayout tr = new LinearLayout(this);
        int cur = U.sp(this).getInt("theme", 0);
        for (int i = 0; i < U.GRADS.length; i++) {
            final int idx = i;
            LinearLayout cell = new LinearLayout(this); cell.setOrientation(LinearLayout.VERTICAL); cell.setGravity(Gravity.CENTER_HORIZONTAL);
            View sw = new View(this);
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, U.GRADS[i]);
            g.setShape(GradientDrawable.OVAL);
            if (i == cur) g.setStroke(U.dp(this, 3), Color.WHITE);
            sw.setBackground(g);
            cell.addView(sw, new LinearLayout.LayoutParams(U.dp(this, 62), U.dp(this, 62)));
            TextView t = new TextView(this); t.setText(U.THEME_NAMES[i]); t.setTextColor(Color.WHITE); t.setTextSize(12);
            cell.addView(t);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2); lp.rightMargin = U.dp(this, 12);
            cell.setOnClickListener(v -> { U.sp(this).edit().putInt("theme", idx).apply(); recreate(); });
            tr.addView(cell, lp);
        }
        hs.addView(tr); col.addView(hs);

        title("Icon shape", 16);
        chips(new String[]{"⚪ Round", "🔷 Squircle", "⬜ Square"}, "shape", new int[]{0, 1, 2}, 1);
        title("Apps per row", 16);
        chips(new String[]{"4", "5", "6"}, "cols", new int[]{4, 5, 6}, 4);

        Switch sw = new Switch(this); sw.setText("Show app names"); sw.setTextColor(Color.WHITE); sw.setTextSize(16);
        sw.setChecked(U.sp(this).getBoolean("labels", true));
        sw.setOnCheckedChangeListener((v, c) -> U.sp(this).edit().putBoolean("labels", c).apply());
        sw.setPadding(0, U.dp(this, 14), 0, U.dp(this, 6));
        col.addView(sw);

        TextView def = btn("⭐ Set as default launcher", 4);
        def.setOnClickListener(v -> { try { startActivity(new Intent(Settings.ACTION_HOME_SETTINGS)); } catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); } });
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1, U.dp(this, 52)); dp.topMargin = U.dp(this, 14);
        col.addView(def, dp);

        title("Phone settings (shortcuts)", 16);
        String[] names = {"Wi-Fi","Bluetooth","Display","Sound","Battery","Apps","Storage","Location","Network","Date & Time","Language","All Settings"};
        String[] emo = {"📶","🔵","🌈","🔔","🔋","📦","💾","📍","📡","🕒","🌐","⚙"};
        String[] acts = {Settings.ACTION_WIFI_SETTINGS, Settings.ACTION_BLUETOOTH_SETTINGS, Settings.ACTION_DISPLAY_SETTINGS,
            Settings.ACTION_SOUND_SETTINGS, Settings.ACTION_BATTERY_SAVER_SETTINGS, Settings.ACTION_APPLICATION_SETTINGS,
            Settings.ACTION_INTERNAL_STORAGE_SETTINGS, Settings.ACTION_LOCATION_SOURCE_SETTINGS, Settings.ACTION_WIRELESS_SETTINGS,
            Settings.ACTION_DATE_SETTINGS, Settings.ACTION_LOCALE_SETTINGS, Settings.ACTION_SETTINGS};
        LinearLayout rowL = null;
        for (int i = 0; i < names.length; i++) {
            if (i % 3 == 0) { rowL = new LinearLayout(this); col.addView(rowL); }
            TextView t = new TextView(this);
            t.setText(emo[i] + "\n" + names[i]); t.setTextColor(Color.WHITE); t.setTextSize(13); t.setGravity(Gravity.CENTER);
            t.setBackground(U.grad(U.PAL[i % U.PAL.length], U.dp(this, 20)));
            final String a = acts[i];
            t.setOnClickListener(v -> { try { startActivity(new Intent(a)); } catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); } });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, U.dp(this, 84), 1);
            lp.setMargins(U.dp(this, 4), U.dp(this, 4), U.dp(this, 4), U.dp(this, 4));
            rowL.addView(t, lp);
        }
    }
    void title(String s, int sz) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(sz > 20 ? Color.WHITE : 0xFFFFE066); t.setTextSize(sz);
        t.setTypeface(null, Typeface.BOLD);
        t.setPadding(0, U.dp(this, 16), 0, U.dp(this, 8)); col.addView(t);
    }
    TextView btn(String s, int pal) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(16); t.setGravity(Gravity.CENTER);
        t.setTypeface(null, Typeface.BOLD);
        t.setBackground(U.grad(U.PAL[pal], U.dp(this, 26))); return t;
    }
    void chips(String[] labels, final String key, int[] vals, int def) {
        LinearLayout r = new LinearLayout(this);
        int cur = U.sp(this).getInt(key, def);
        for (int i = 0; i < labels.length; i++) {
            final int v = vals[i];
            TextView t = btn(labels[i], (i * 3 + 1) % U.PAL.length);
            if (v != cur) t.setBackground(U.round(0x44FFFFFF, U.dp(this, 26)));
            t.setOnClickListener(x -> { U.sp(this).edit().putInt(key, v).apply(); recreate(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, U.dp(this, 48), 1);
            lp.rightMargin = U.dp(this, 8);
            r.addView(t, lp);
        }
        col.addView(r);
    }
}
